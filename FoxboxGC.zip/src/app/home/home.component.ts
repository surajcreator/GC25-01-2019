import { Component } from "@angular/core";
import { SwiperComponent, SwiperDirective, SwiperConfigInterface,
    SwiperScrollbarInterface, SwiperPaginationInterface } from 'ngx-swiper-wrapper';

@Component({
    selector:"homeWrapper",
    templateUrl: "./home.component.html" 
})

export class homeComponent{
    public config: SwiperConfigInterface = {
        direction: 'horizontal',
        slidesPerView: 1,
        keyboard: true,
        mousewheel: false,
        scrollbar: false,
        navigation: true,
        pagination: false,
        autoplay: true,
      };
}