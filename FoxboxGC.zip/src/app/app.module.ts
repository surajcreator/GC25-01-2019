import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SwiperModule } from "ngx-swiper-wrapper";
import { SWIPER_CONFIG } from "ngx-swiper-wrapper";
import { SwiperConfigInterface } from "ngx-swiper-wrapper";
import { HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { replaceSpace } from './remove-space.pipe';

//import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from "./app.component";
import { homeComponent } from "./home/home.component";
import { gcSliderComponent } from "./card-slider/gcSlider.component";
import { ProductsService } from "./products.service";
import { listingComponent } from "./gift-cards/listing.component";
import { VoucherDetailPageComponent } from "./voucher-detail-page/voucher-detail-page.component";
import { FriendBuyComponent } from './friend-buy/friend-buy.component';
import { SelfBuyComponent } from './self-buy/self-buy.component';
import { BulkBuyComponent } from './bulk-buy/bulk-buy.component';
import { BenefitWidgetComponent } from './benefit-widget/benefit-widget.component';
import { TrendingCardsComponent } from './trending-cards/trending-cards.component';
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { from } from "rxjs";


const appRoutes: Routes = [
  { path: "home", component: homeComponent },
  { path: "gift-cards", component: listingComponent },
  { 
    path: "gift-cards/:title/:product_id", 
    component: VoucherDetailPageComponent,
    children:[
      {path:"friend-buy", component:FriendBuyComponent},
      {path:"self-buy", component:SelfBuyComponent},
      {path:"bulk-buy", component:BulkBuyComponent},
    ]
  },
  { path: "", redirectTo: "home", pathMatch: "full" },
  { path: "**", component: PageNotFoundComponent }
];

const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
  direction: "horizontal",
  slidesPerView: "auto"
};

@NgModule({
  declarations: [
    AppComponent,
    homeComponent, 
    gcSliderComponent,
    listingComponent,
    VoucherDetailPageComponent,
    FriendBuyComponent,
    SelfBuyComponent,
    BulkBuyComponent,
    replaceSpace,
    PageNotFoundComponent,
    BenefitWidgetComponent,
    TrendingCardsComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),
    SwiperModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [
    ProductsService,
    {
      provide: SWIPER_CONFIG,
      useValue: DEFAULT_SWIPER_CONFIG
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
