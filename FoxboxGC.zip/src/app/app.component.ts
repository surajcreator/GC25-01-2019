import { Component, OnInit, OnDestroy } from "@angular/core";
import { fadeAnimation } from "./animation";
import { Router, NavigationEnd } from "@angular/router";
import { Navigation } from "selenium-webdriver";
import { filter } from "rxjs/operators";
import { Subscription } from "rxjs";
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
  animations: [fadeAnimation] // register the animation
})
export class AppComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  title = "FoxboxGC";
  base_url = "http://www.foxboxgiftcards.com/";
  store_logo = "../assets/images/foxbox-gift-vouchers-logo.png";
  primary_contact = "9833564369";

  constructor(private router: Router, private modalService: NgbModal) {}
  //openBackDropCustomClass(content) {
    //this.modalService.open(content, {backdropClass: 'light-blue-backdrop'});
  //}

  ngOnInit() {
    this.subscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => window.scrollTo(0, 0));
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
