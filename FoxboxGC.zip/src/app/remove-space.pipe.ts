import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'removespace'
})


export class replaceSpace implements PipeTransform{
    transform(value: any, args?: any): string{
       return value.replace(" ", "-");
    }
}
