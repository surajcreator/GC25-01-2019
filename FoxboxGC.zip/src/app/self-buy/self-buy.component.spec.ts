import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelfBuyComponent } from './self-buy.component';

describe('SelfBuyComponent', () => {
  let component: SelfBuyComponent;
  let fixture: ComponentFixture<SelfBuyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelfBuyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelfBuyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
