import { Component, OnInit } from '@angular/core';
import { VoucherDetailPageComponent } from '../voucher-detail-page/voucher-detail-page.component';

@Component({
  selector: 'app-self-buy',
  templateUrl: './self-buy.component.html',
})
export class SelfBuyComponent implements OnInit {
  private title;
  constructor(public formTitle:VoucherDetailPageComponent){

  }

  ngOnInit() {
    this.title = this.formTitle.form_title_part2
  }
}
