import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-benefit-widget',
  templateUrl: './benefit-widget.component.html',
})
export class BenefitWidgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
