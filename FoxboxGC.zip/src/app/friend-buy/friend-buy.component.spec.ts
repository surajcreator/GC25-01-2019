import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FriendBuyComponent } from './friend-buy.component';

describe('FriendBuyComponent', () => {
  let component: FriendBuyComponent;
  let fixture: ComponentFixture<FriendBuyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FriendBuyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FriendBuyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
