import { Component, OnInit } from '@angular/core';
import { VoucherDetailPageComponent } from '../voucher-detail-page/voucher-detail-page.component';
import { homeComponent } from '../home/home.component';
import { from } from 'rxjs/internal/observable/from';
import { Input } from '@angular/core/src/metadata/directives';

@Component({
  selector: 'app-friend-buy',
  templateUrl: './friend-buy.component.html',
})
export class FriendBuyComponent implements OnInit {
  private title;
  constructor(public formTitle:VoucherDetailPageComponent){
    
  }

  ngOnInit(){
    this.title = this.formTitle.form_title_part1;
  }
}
