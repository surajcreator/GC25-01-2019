import { Component, OnInit } from '@angular/core';
import { ProductsService } from "../products.service";

@Component({
  selector: 'app-trending-cards',
  templateUrl: './trending-cards.component.html',
})
export class TrendingCardsComponent implements OnInit {

  public products = [];

  constructor(private _productsService: ProductsService) {}

  ngOnInit() {
    this._productsService
      .getProducts()
      .subscribe(data => (this.products = data));
  }

}
