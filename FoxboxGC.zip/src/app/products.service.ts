import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { IProducts } from "./products";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class ProductsService {
  constructor(private http: HttpClient) {}

  //productAPI: string = "/products.json";
  productAPI: string = "http://www.foxboxgiftcards.com/fbgiftcard/API/foxboxapi.php?case=productlistingall";
  singleProductAPI: string = "http://www.foxboxgiftcards.com/fbgiftcard/API/foxboxapi.php?case=fetchproductbyId&product_id="


  getProducts(): Observable<IProducts[]> {
    return this.http.get<IProducts[]>(this.productAPI);
  }

  getSingleProducts(podctId ? ): Observable<IProducts[]> {
    return this.http.get<IProducts[]>(this.singleProductAPI + podctId);
  }
}
