import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ProductsService } from '../products.service';

@Component({
  selector: 'app-voucher-detail-page',
  templateUrl: './voucher-detail-page.component.html',
})
export class VoucherDetailPageComponent implements OnInit {
  private id: string;
  private prodName : any;
  
  constructor(private route: ActivatedRoute, private singleProAPI: ProductsService) {
    //console.log(activatedRoute.snapshot.url[2]);
    this.id = this.route.snapshot.paramMap.get('product_id');

    if(this.id){
      this.singleProAPI.getSingleProducts(this.id).subscribe(
        Response => {
          this.prodName = Response;
          console.log(Response)
        });
    }
  }

  form_title_part1: string = "Send to friend";
  form_title_part2: string = "Buy for yourself";
  form_title_part3: string = "Bulk Inquiry";

  ngOnInit(){
    
    console.log(this.id);
    
  }
}
