import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherDetailPageComponent } from './voucher-detail-page.component';

describe('VoucherDetailPageComponent', () => {
  let component: VoucherDetailPageComponent;
  let fixture: ComponentFixture<VoucherDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoucherDetailPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoucherDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
