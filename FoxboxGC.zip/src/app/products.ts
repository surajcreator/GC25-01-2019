export interface IProducts {
  product_id: number;
  title: string;
  image_url: string;
  text: string;
  terms_n_condition : any;
  //url: string;
}