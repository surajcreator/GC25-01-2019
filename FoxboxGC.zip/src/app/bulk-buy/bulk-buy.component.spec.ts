import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkBuyComponent } from './bulk-buy.component';

describe('BulkBuyComponent', () => {
  let component: BulkBuyComponent;
  let fixture: ComponentFixture<BulkBuyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkBuyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkBuyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
