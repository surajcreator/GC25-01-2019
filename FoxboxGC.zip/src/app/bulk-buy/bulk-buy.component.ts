import { Component, OnInit } from '@angular/core';
import { VoucherDetailPageComponent } from '../voucher-detail-page/voucher-detail-page.component';

@Component({
  selector: 'app-bulk-buy',
  templateUrl: './bulk-buy.component.html',
})
export class BulkBuyComponent implements OnInit {
  private title;
  constructor(public formTitle:VoucherDetailPageComponent ){}

  ngOnInit() {
    this.title = this.formTitle.form_title_part3
  }
}
