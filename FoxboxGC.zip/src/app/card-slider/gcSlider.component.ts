import { Component, OnInit } from "@angular/core";
import { ProductsService } from "../products.service";

import {
  SwiperComponent,
  SwiperDirective,
  SwiperConfigInterface,
  SwiperScrollbarInterface,
  SwiperPaginationInterface
} from "ngx-swiper-wrapper";

@Component({
  selector: "gc-slider",
  templateUrl: "./gcSlider.component.html"
})
export class gcSliderComponent implements OnInit {
  public products = [];

  constructor(private _productsService: ProductsService) {}

  ngOnInit() {
    this.config;
    this._productsService
      .getProducts()
      .subscribe(data => (this.products = data));
  }

  public config: SwiperConfigInterface = {
    direction: "horizontal",
    slidesPerView: 6,
    spaceBetween: 20,
    breakpoints: {
      // when window width is <= 320px
      320: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      // when window width is <= 480px
      480: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      // when window width is <= 768px
      768: {
        slidesPerView: 3,
        spaceBetween: 30
      }
    },
    keyboard: true,
    mousewheel: false,
    scrollbar: false,
    navigation: true,
    pagination: false,
    autoplay: true
  };
}
